// #ifndef MOTOR_CONTROL_FUNCTIONS_H
// #define MOTOR_CONTROL_FUNCTIONS_H

// #include "Arduino_BMI270_BMM150.h"

// void moveWheelsBackward(int pwmInput);
// void moveWheelsForward(int pwmInput);
// void stopWheels();

// #endif
