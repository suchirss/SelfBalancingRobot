// #include "motor_control_functions.h" 

// // ---------------  Pin Assignments  ---------------
// const int pwmA1 = 9;   // PWM output for Motor A
// const int pwmA2 = 10;  // PWM output for Motor A
// const int pwmB1 = 5;   // PWM output for Motor B
// const int pwmB2 = 6;   // PWM output for Motor B

// void moveWheelsBackward(int pwmInput) {
//   analogWrite(pwmA1, 255);
//   analogWrite(pwmA2, 255-pwmInput);
//   analogWrite(pwmB1, 255);
//   analogWrite(pwmB2, 255-pwmInput);
// }

// void moveWheelsForward(int pwmInput) {
//   analogWrite(pwmA1, 255-pwmInput);
//   analogWrite(pwmA2, 255);
//   analogWrite(pwmB1, 255-pwmInput);
//   analogWrite(pwmB2, 255);
// }

// void stopWheels() {
//   analogWrite(pwmA1, 255);
//   analogWrite(pwmA2, 255);
//   analogWrite(pwmB1, 255);
//   analogWrite(pwmB2, 255);
// }
